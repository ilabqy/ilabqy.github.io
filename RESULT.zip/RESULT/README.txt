left.bmp and right.bmp 

leftgt.bmp,rightdt.bmp:the groundtruth of the segmentation for left and right image.

leftDis.bmp,rightDis.bmp: the disparity maps of the orginal images.

leftRes.bmp,rightRes.bmp: the segment results by the method DispDis.

leftResWithout.bmp,rightResWithout.bmp: the segment results by our method.

leftResWithout_Var.bmp,rightResWithout_Var.bmp: the segment results by the method DispVar.

leftRes_Var.bmp,rightRes_Var.bmp:the segment result by the method SC[1].

grabCutSegResult.bmp,grabCutSegResult2.bmp:the segment results by the method SGC[2].

leftResSIFT.bmp,rightResSIFT.bmp:sthe segment results by the method FC[3].






[1] Price, S. Cohen "StereoCut: consistent interactive object selection in stereo image pairs", in ICCV, 2011.
[2] R. Ju, X. Xu, Y. Yang, G. Wu, ��Stereo GrabCut: Interactive and consistent object extraction for stereo images,�� in Advances in Multimedia Information Processing �C PCM ,2013.
[3] W. Ma, L. Yang, Y. Zhang, L. Duan, ��Fast interactive stereo image segmentation,�� Multimedia Tools and Applications,2015.

