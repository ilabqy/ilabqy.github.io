    This data set consists of a set of 37 stereo image pairs, together with 
    three input images for each: the ground truth,the stroke and the disparity map.  
    The purpose of the data set is to test selection algorithms on stereo image pairs.
    
    This data set consists of a set of 37 stereo image pairs, together with three input 
    images for each: the ground truth,the stroke and the disparity map. The purpose of 
    the data set is to test selection algorithms on stereo image pairs. 
    The original images ��No.1-30�� from the Adobe Stereo Selection Data Set[1]. 
    The images in the Adobe Stereo Selection Data Set must be downloaded from 
    http://www.adobe.com/go/datasets on the datasets page. The images (No.31-No.32)
    selected from http://vision.middlebury.edu/stereo/data/.
   The another five stereo image pairs (No.33-37) selected from the dataset in [2].
    The images must be download as following:
   No.31:2006 dataset[3,4] (http://vision.middlebury.edu/stereo/data/scenes2006/):baby3
   No.32:2005 dataset[3,4] (http://vision.middlebury.edu/stereo/data/scenes2005/):Reindeer
   No.33:dataset[2](http://web.cecs.pdx.edu/~fliu/project/stereo-saliency/):#4
   No.34:dataset[2](http://web.cecs.pdx.edu/~fliu/project/stereo-saliency/):#403
   No.35:dataset[2](http://web.cecs.pdx.edu/~fliu/project/stereo-saliency/):#460
   No.36:dataset[2](http://web.cecs.pdx.edu/~fliu/project/stereo-saliency/):#605

     Each folder present a data set for a single stereo image pair.In each folder the files are as
      follows:   
     left.bmp:the left view of the stereo image pair.    
     right.bmp:the right view of the stereo image pair. 
     leftgt.bmp:the ground truth of the left image.
     rightgt.bmp:the ground truth of the right image.
     leftDis.bmp:the disparty map of the left view.
     rightDis.bmp:the disparty map of the right view.
     stroke.txt:the input stroke of the left image.
     strokePreview.bmp:the preview of the stroke,the red line present the mark of the forground��
     the blue line present the mark of the background��


    

[1]Price, S. Cohen  "StereoCut: Consistent Interactive Object Selection in Stereo Image Pairs", IEEE International Conference on Computer Vision, 2011.
segmentation. In: European conference on computer vision, pp 1�C15
[2]Niu Y, Geng Y, Li X, Liu F (2012) Leveraging stereopsis for saliency analysis. In: IEEE conference on
computer vision and pattern recognition, pp 454�C461
[3] D. Scharstein and C. Pal. "Learning conditional random fields for stereo," IEEE Computer Society Conference on Computer Vision and Pattern Recognition, 2007.
[4] Heiko Hirschm��ulle and D. Scharstein. "Evaluation of cost functions for stereo matching", IEEE Computer Society Conference on Computer Vision and Pattern Recognition, 2007. 