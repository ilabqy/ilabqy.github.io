    This data set consists of a set of 37 stereo image pairs, together with 
    three input images for each: the ground truth,the stroke and the disparity map.  
    The purpose of the data set is to test selection algorithms on stereo image pairs.
    
     The images consist of original images incllude ground truth��No.1-31��taken by the
     authors and images from the Adobe Stereo Selection Data Set[1]. 
      The images in the Adobe Stereo Selection Data Set can be 
     downloaded from  http://www.adobe.com/go/datasets on the datasets page.

     The another six stereo image pairs together with the ground truth (No.32-37) selected from the 
     dataset in [2].In the dataset,we can 
     Each folder present a data set for a single stereo image pair.In each folder the files are as
      follows:   
     left.bmp:the left view of the stereo image pair.    
     right.bmp:the right view of the stereo image pair. 
     leftgt.bmp:the ground truth of the left image.
     rightgt.bmp:the ground truth of the right image.
     leftDis.bmp:the disparty map of the left view.
     rightDis.bmp:the disparty map of the right view.
     stroke.txt:the input stroke of the left image.
     strokePreview.bmp:the preview of the stroke,the red line present the mark of the forground��
     the blue line present the mark of the background��


    

[1]Price, S. Cohen  "StereoCut: Consistent Interactive Object Selection in Stereo Image Pairs", IEEE International Conference on Computer Vision, 2011.
segmentation. In: European conference on computer vision, pp 1�C15
[2]Niu Y, Geng Y, Li X, Liu F (2012) Leveraging stereopsis for saliency analysis. In: IEEE conference on
computer vision and pattern recognition, pp 454�C461