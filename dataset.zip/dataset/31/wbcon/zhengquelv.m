a=imread('leftgt.bmp');
b1=imread('leftRes_var.bmp');

b2=imread('leftRes.bmp');
b3=imread('leftResWithout_var.bmp');

b4=imread('leftResWithout.bmp');
b5=imread('leftResWithoutGra.bmp');

ee=size(a);
chang=ee(1);
kuan=ee(2);

m1=0;
m2=0;
m3=0;
m4=0;
m5=0;
for i=1:chang
    for j=1:kuan
        if a(i,j)==b1(i,j);
          m1=m1+1;
        end
        if a(i,j)==b2(i,j);
          m2=m2+1;
        end
        if a(i,j)==b3(i,j);
          m3=m3+1;
        end
        if a(i,j)==b4(i,j);
          m4=m4+1;
        end
        if a(i,j)==b5(i,j);
          m5=m5+1;
        end
    end
end
 l1=m1/(chang*kuan);
 l2=m2/(chang*kuan);
 l3=m3/(chang*kuan);
 l4=m4/(chang*kuan);
 l5=m5/(chang*kuan);
c=imread('rightgt.bmp');
e1=imread('rightRes_var.bmp');


e2=imread('rightRes.bmp');
e3=imread('rightResWithout_Var.bmp');

e4=imread('rightResWithout.bmp');
e5=imread('rightResWithoutGra.bmp');

n1=0;
n2=0;
n3=0;n4=0;n5=0;
 for i=1:chang
    for j=1:kuan
         if c(i,j)==e1(i,j);
          n1=n1+1;
        end
         if c(i,j)==e2(i,j);
          n2=n2+1;
         end
         if c(i,j)==e3(i,j);
          n3=n3+1;
         end
         if c(i,j)==e4(i,j);
          n4=n4+1;
         end
         if c(i,j)==e5(i,j);
          n5=n5+1;
         end
    end
 end
 r1=n1/(chang*kuan);
 r2=n2/(chang*kuan);
 r3=n3/(chang*kuan);
 r4=n4/(chang*kuan);
 r5=n5/(chang*kuan);
double zhengque1;
 double zhengque2;
 double zhengque3;
 double zhengque4;
 double zhengque5;
  zhengque1=(l1+r1)/2;
  zhengque2=(l2+r2)/2;
   zhengque3=(l3+r3)/2;
    zhengque4=(l4+r4)/2;
     zhengque5=(l5+r5)/2;
     fprintf(' zheng1\n');
 fprintf(' SCut %f\n',zhengque4);

fprintf(' dis %f\n',zhengque2);
fprintf(' var %f\n',zhengque3);
fprintf(' our method %f\n',zhengque1);
fprintf(' Gra %f\n',zhengque5);
 
